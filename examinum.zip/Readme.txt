examinum-frontend:
1. npm install
2. npm start

examinum-backend:
1. Install lombock plugin in your IDE. Follow installations steps from this post:
https://stackoverflow.com/a/45217235/12232627
2. Let IDE finish downloading required packages
3. Run as "Spring Boot App"